<?php
/*
Copyright 09-Januari-2020
MASCMS V1.0 (MAS Content Management System)
Coded by : Mohamad Abdul Sobur
Based on PHP NATIVE
*/
$slogan_lang = "Download Anime Subtitle Indonesia English Best Quality";
$slogan2_lang = "Made with Love in Indramayu, Indonesia";
$slogan3_lang = "<b>$sitename</b> Is the best anime subtitle English ever. <br/> Get anime subtitle English for free with the fastest server download!";
$title_index_lang = "$sitename - $slogan_lang $tahun";

$category_lang = "Category";
$no_category_lang = "There's nothing category to show!";
$about_us_lang = "About us";
$home_lang = "Home";
$more_category_lang = "More Category";
$keyword_lang = "Keyword";
$keyword_nothing_lang = "There's nothing post with keyword";
$latest_update_lang = "Latest Update";
$posted_on_lang = "Posted on";
$hits_lang = "Hits";
$recomendation_lang = "Anime Recomendation";
$illegal_string_lang = "Illegal string detected!";
$subscribe_lang = "Subscribe";
$subscribe_desc_lang = "Enter your email for get the latest notification from our website!";
$has_subs_lang = "This mail already exist!";
$subs_success_lang = "Thanks for subscribing!";
$unsubs_lang = "Unsubscribe success!";
$unsubs_fail_lang = "Failed to unsubscribe, are you subscribe this site before ?";
$go_lang = "Go to destination link!";
$shortlink_explanation_lang = "The button to link destination will be show on 10 Seconds!";
$shortlink_notfound_lang = "Destination Link are not found or deleted by admin, Please contact admin support!";
$keyword_lang = "Keyword";
$all_keyword = "All Post";
$reply_lang = "Write Comments";
$comments_lang = "Comments";
$send_lang = "Send";
$accept_notification = "Accept Receiver by email when there is the latest post from";
$not_available_lang = "This post are not available!";
$comments_rule_lang = "Comment must be at least 15 characters!";
$empty_comments_lang = "Make sure you have fill the form!<br/>Please read the rules before making new comments , because we have a Hard Filter Comments , Maybe, Your comments included a Blocked Word!";
$comments_error = "Comments failed to publish!";
$comments_not_available_lang = "0 Comments...<br/>Write comments below!";
$comments_rules_lang = "Please read the following rules: <br/>Dont write said rude, mocking, religion, tribe, state. <br/>Prohibited promotion / selling.<br/>Prohibited from including URL links.<br/>Spam.<br/>Comments feature already given a spam filter & a dirty word filter!";
$language_lang = "Language";
?>