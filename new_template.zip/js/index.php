<?php
header("location: ../home");
?>