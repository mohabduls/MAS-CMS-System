<?php
header("location: ../../home");
?>