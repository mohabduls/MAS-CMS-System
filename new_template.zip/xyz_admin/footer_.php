<?php
/*
Copyright 09-Januari-2020
MASCMS V1.0 (MAS Content Management System)
Coded by : Mohamad Abdul Sobur
Based on PHP NATIVE
*/
?>
</div>
<div class="d-footer">
  <center>
        <h3 class="h-title">2019 <?php echo $version_code." - ".$sitename; ?><br/> Made with Love by<br/><b>Mohamad Abdul Sobur</b></h3>
  </center>
</div>
</body>
</html>