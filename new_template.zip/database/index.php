<?php
header("location: ../home.asp");
?>